var image1 = document.getElementById('image1');

image1.addEventListener('click', function(image1){
    image1.target.classList.toggle('myClickState');
}) 

var image2 = document.getElementById('image2');

image2.addEventListener('click', function(image2){
    image2.target.classList.toggle('myClickState');
}) 

var image3 = document.getElementById('image3');

image3.addEventListener('click', function(image3){
    image3.target.classList.toggle('myClickState');
}) 


var image4 = document.getElementById('image4');

image4.addEventListener('click', function(image4){
    image4.target.classList.toggle('myClickState');
}) 


var image5 = document.getElementById('image5');

image5.addEventListener('click', function(image5){
    image5.target.classList.toggle('myClickState');
}) 


var image6 = document.getElementById('image6');

image6.addEventListener('click', function(image6){
    image6.target.classList.toggle('myClickState');
}) 


var image7 = document.getElementById('image7');

image7.addEventListener('click', function(image7){
    image7.target.classList.toggle('myClickState');
}) 


var image8 = document.getElementById('image8');

image8.addEventListener('click', function(image8){
    image8.target.classList.toggle('myClickState');
}) 


var image9 = document.getElementById('image9');

image9.addEventListener('click', function(image9){
    image9.target.classList.toggle('myClickState');
}) 